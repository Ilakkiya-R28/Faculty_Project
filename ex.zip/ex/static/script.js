/**
 * Faculty Schedule Manager - Main JavaScript
 * Handles calendar upload, date checking, and timetable management
 */

// ==================== GLOBAL VARIABLES ====================
let currentEditingCell = null;
let timetableData = {};
let facultyId = null;

// ==================== INITIALIZATION ====================
document.addEventListener('DOMContentLoaded', function() {
    console.log('Faculty Schedule Manager Initialized');
    
    // Set today's date in date input
    const today = new Date().toISOString().split('T')[0];
    const dateInput = document.getElementById('dateInput');
    if (dateInput) {
        dateInput.value = today;
        dateInput.max = new Date(new Date().getFullYear() + 1, 11, 31).toISOString().split('T')[0];
        dateInput.min = new Date(new Date().getFullYear() - 1, 0, 1).toISOString().split('T')[0];
        
        // Auto-check today's date
        setTimeout(checkDate, 500);
    }
    
    // Initialize today's date display
    const todayDate = document.getElementById('todayDate');
    if (todayDate && !todayDate.textContent.includes('{{')) {
        const date = new Date();
        const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
        todayDate.textContent = date.toLocaleDateString('en-US', options);
    }
    
    // Initialize week view
    if (document.getElementById('weekView')) {
        generateWeekView();
    }
    
    // Load upcoming events
    loadUpcomingEvents();
    
    // Check for saved faculty ID
    if (localStorage.getItem('facultyId')) {
        facultyId = localStorage.getItem('facultyId');
        const facultyIdElement = document.getElementById('facultyId');
        if (facultyIdElement) {
            facultyIdElement.textContent = facultyId;
        }
    }
    
    // Setup drag and drop
    setupDragAndDrop();
    
    // Setup keyboard shortcuts
    setupKeyboardShortcuts();
    
    // Check if we're on timetable page
    if (window.location.pathname.includes('timetable')) {
        initializeTimetable();
    }
});

// ==================== DATE CHECKING ====================
async function checkDate() {
    const dateInput = document.getElementById('dateInput');
    const dateInfo = document.getElementById('dateInfo');
    const dayType = document.getElementById('dayType');
    const dayDescription = document.getElementById('dayDescription');
    
    if (!dateInput || !dateInput.value) {
        if (dateInfo) dateInfo.textContent = 'Please select a date';
        return;
    }
    
    try {
        // Show loading state
        if (dateInfo) dateInfo.textContent = 'Checking date...';
        if (dayType) {
            dayType.textContent = 'Checking...';
            dayType.className = 'day-type unknown';
        }
        
        const response = await fetch('/check_date', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ date: dateInput.value })
        });
        
        const data = await response.json();
        
        if (data.error) {
            showError(data.error);
            return;
        }
        
        // Update display
        if (dateInfo) {
            const dateObj = new Date(data.date);
            const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
            dateInfo.textContent = dateObj.toLocaleDateString('en-US', options);
        }
        
        if (dayType) {
            dayType.textContent = data.day_type.toUpperCase();
            dayType.className = 'day-type ' + data.day_type.replace(' ', '-');
        }
        
        if (dayDescription) {
            dayDescription.textContent = data.description;
        }
        
    } catch (error) {
        showError('Error checking date: ' + error.message);
    }
}

function checkToday() {
    const today = new Date().toISOString().split('T')[0];
    const dateInput = document.getElementById('dateInput');
    if (dateInput) {
        dateInput.value = today;
        checkDate();
    }
}

function setDate(dateStr) {
    const dateInput = document.getElementById('dateInput');
    if (dateInput) {
        dateInput.value = dateStr;
        checkDate();
    }
}

// ==================== CALENDAR UPLOAD ====================
async function uploadCalendar() {
    const fileInput = document.getElementById('calendarFile');
    const uploadStatus = document.getElementById('uploadStatus');
    
    if (!fileInput || !fileInput.files.length) {
        showError('Please select a file to upload');
        return;
    }
    
    const formData = new FormData();
    formData.append('calendar_file', fileInput.files[0]);
    
    // Add calendar name if available
    const calendarName = document.getElementById('calendarName');
    if (calendarName && calendarName.value) {
        formData.append('calendar_name', calendarName.value);
    }
    
    try {
        if (uploadStatus) {
            uploadStatus.innerHTML = '<div class="working-day"><i class="fas fa-spinner fa-spin"></i> Uploading file...</div>';
        }
        
        const response = await fetch('/upload_calendar', {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        
        if (uploadStatus) {
            if (data.success) {
                uploadStatus.innerHTML = `
                    <div class="working-day">
                        <i class="fas fa-check-circle"></i> ${data.message}<br><br>
                        <strong>Summary:</strong><br>
                        ✓ Working Days: ${data.summary.working_days}<br>
                        ✓ Holidays: ${data.summary.holidays}<br>
                        ✓ Special Days: ${data.summary.special_days}<br><br>
                        <small>File: ${data.filename}</small>
                    </div>
                `;
                
                // Reload week view
                generateWeekView();
                loadUpcomingEvents();
                
                // Clear file input
                if (fileInput) fileInput.value = '';
                
            } else {
                uploadStatus.innerHTML = `<div class="holiday"><i class="fas fa-exclamation-circle"></i> Error: ${data.error}</div>`;
            }
        }
        
    } catch (error) {
        if (uploadStatus) {
            uploadStatus.innerHTML = `<div class="holiday"><i class="fas fa-exclamation-circle"></i> Upload failed: ${error.message}</div>`;
        }
    }
}

async function uploadFile() {
    await uploadCalendar();
}

// ==================== WEEK VIEW ====================
async function generateWeekView() {
    const weekGrid = document.getElementById('weekView');
    if (!weekGrid) return;
    
    try {
        const response = await fetch('/get_week_schedule', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({})
        });
        
        const data = await response.json();
        
        if (data.error) {
            weekGrid.innerHTML = '<p>Error loading week view</p>';
            return;
        }
        
        weekGrid.innerHTML = '';
        
        if (data.week_schedule && data.week_schedule.length > 0) {
            data.week_schedule.forEach(day => {
                const dayCell = document.createElement('div');
                dayCell.className = `day-cell ${day.day_type}`;
                dayCell.innerHTML = `
                    <div class="day-name">${day.day_name}</div>
                    <div class="day-number">${day.date.split('-')[2]}</div>
                `;
                
                // Add click event
                dayCell.onclick = () => {
                    const dateInput = document.getElementById('dateInput');
                    if (dateInput) {
                        dateInput.value = day.date;
                        checkDate();
                    }
                };
                
                // Add tooltip for holidays/special days
                if (day.day_type !== 'working') {
                    dayCell.title = day.description;
                }
                
                weekGrid.appendChild(dayCell);
            });
        } else {
            // Generate default week view
            generateDefaultWeekView();
        }
        
    } catch (error) {
        console.error('Error generating week view:', error);
        generateDefaultWeekView();
    }
}

function generateDefaultWeekView() {
    const weekGrid = document.getElementById('weekView');
    if (!weekGrid) return;
    
    weekGrid.innerHTML = '';
    
    const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const today = new Date();
    const startOfWeek = new Date(today);
    startOfWeek.setDate(today.getDate() - today.getDay() + 1); // Start from Monday
    
    for (let i = 0; i < 6; i++) {
        const currentDate = new Date(startOfWeek);
        currentDate.setDate(startOfWeek.getDate() + i);
        const dateStr = currentDate.toISOString().split('T')[0];
        const dayName = days[i];
        const dayNum = currentDate.getDate();
        
        const dayCell = document.createElement('div');
        dayCell.className = 'day-cell working';
        dayCell.innerHTML = `
            <div class="day-name">${dayName}</div>
            <div class="day-number">${dayNum}</div>
        `;
        
        dayCell.onclick = () => {
            const dateInput = document.getElementById('dateInput');
            if (dateInput) {
                dateInput.value = dateStr;
                checkDate();
            }
        };
        
        weekGrid.appendChild(dayCell);
    }
}

// ==================== UPCOMING EVENTS ====================
async function loadUpcomingEvents() {
    const eventsList = document.getElementById('upcomingEvents');
    if (!eventsList) return;
    
    try {
        const response = await fetch('/get_upcoming_events');
        const data = await response.json();
        
        if (data.error) {
            eventsList.innerHTML = '<p>Error loading events</p>';
            return;
        }
        
        if (data.upcoming_events && data.upcoming_events.length > 0) {
            eventsList.innerHTML = '';
            
            data.upcoming_events.forEach(event => {
                const eventDiv = document.createElement('div');
                eventDiv.className = 'event-item';
                
                const eventDate = new Date(event.date);
                const dateStr = eventDate.toLocaleDateString('en-US', { 
                    month: 'short', 
                    day: 'numeric',
                    year: 'numeric'
                });
                
                const icon = event.type === 'holiday' ? 'fa-calendar-times' : 'fa-calendar-star';
                
                eventDiv.innerHTML = `
                    <div class="event-icon">
                        <i class="fas ${icon}"></i>
                    </div>
                    <div class="event-content">
                        <div class="event-title">${event.description}</div>
                        <div class="event-date">${dateStr} (${event.day_name})</div>
                    </div>
                    <div class="event-days">${event.days_until} days</div>
                `;
                
                eventsList.appendChild(eventDiv);
            });
        } else {
            eventsList.innerHTML = '<p>No upcoming events found. Upload a calendar to see holidays.</p>';
        }
    } catch (error) {
        console.error('Error loading events:', error);
        eventsList.innerHTML = '<p>Unable to load events</p>';
    }
}

// ==================== DRAG AND DROP ====================
function setupDragAndDrop() {
    const dropArea = document.getElementById('dropArea');
    if (!dropArea) return;
    
    // Prevent default drag behaviors
    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        dropArea.addEventListener(eventName, preventDefaults, false);
        document.body.addEventListener(eventName, preventDefaults, false);
    });
    
    // Highlight drop area
    ['dragenter', 'dragover'].forEach(eventName => {
        dropArea.addEventListener(eventName, highlight, false);
    });
    
    ['dragleave', 'drop'].forEach(eventName => {
        dropArea.addEventListener(eventName, unhighlight, false);
    });
    
    // Handle dropped files
    dropArea.addEventListener('drop', handleDrop, false);
    
    function preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }
    
    function highlight() {
        dropArea.classList.add('highlight');
    }
    
    function unhighlight() {
        dropArea.classList.remove('highlight');
    }
    
    function handleDrop(e) {
        const dt = e.dataTransfer;
        const files = dt.files;
        const fileInput = document.getElementById('calendarUpload');
        
        if (files.length) {
            fileInput.files = files;
            
            // Show selected file name
            const fileNameDiv = document.getElementById('selectedFileName');
            if (fileNameDiv) {
                fileNameDiv.textContent = `Selected: ${files[0].name}`;
                fileNameDiv.style.display = 'block';
            }
            
            // Auto-upload if on home page
            if (window.location.pathname === '/') {
                setTimeout(uploadCalendar, 500);
            }
        }
    }
}

// ==================== TIMETABLE FUNCTIONS ====================
function initializeTimetable() {
    generateTimetable();
    loadTimetable();
    updateStats();
}

function generateTimetable() {
    const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const periods = 8;
    const tbody = document.getElementById('timetableBody');
    
    if (!tbody) return;
    
    tbody.innerHTML = '';
    
    days.forEach(day => {
        const row = document.createElement('tr');
        
        // Day cell
        const dayCell = document.createElement('td');
        dayCell.className = 'day-label';
        dayCell.textContent = day;
        row.appendChild(dayCell);
        
        // Period cells
        for (let period = 1; period <= periods; period++) {
            const periodCell = document.createElement('td');
            const cellContent = document.createElement('div');
            cellContent.className = 'period-cell empty';
            cellContent.setAttribute('data-day', day);
            cellContent.setAttribute('data-period', period);
            cellContent.onclick = () => openPeriodEditor(day, period, cellContent);
            
            // Add period number
            const periodNum = document.createElement('div');
            periodNum.className = 'period-number';
            periodNum.textContent = `P${period}`;
            cellContent.appendChild(periodNum);
            
            // Add placeholder
            const placeholder = document.createElement('div');
            placeholder.className = 'period-placeholder';
            placeholder.textContent = 'Click to edit';
            cellContent.appendChild(placeholder);
            
            periodCell.appendChild(cellContent);
            row.appendChild(periodCell);
        }
        
        tbody.appendChild(row);
    });
}

function openPeriodEditor(day, period, cellElement) {
    currentEditingCell = { day, period, element: cellElement };
    
    const selectedInfo = document.getElementById('selectedPeriodInfo');
    const subjectInput = document.getElementById('subject');
    const classTypeSelect = document.getElementById('classType');
    const roomInput = document.getElementById('room');
    const batchInput = document.getElementById('batch');
    const notesInput = document.getElementById('notes');
    
    if (selectedInfo) {
        selectedInfo.textContent = `${day}, Period ${period} (${getTimeForPeriod(period)})`;
        selectedInfo.className = 'selected-period active';
        
        // Load existing data
        const key = `${day}-${period}`;
        if (timetableData[key]) {
            const data = timetableData[key];
            subjectInput.value = data.subject || '';
            classTypeSelect.value = data.type || 'lecture';
            roomInput.value = data.room || '';
            batchInput.value = data.batch || '';
            notesInput.value = data.notes || '';
        } else {
            subjectInput.value = '';
            classTypeSelect.value = 'lecture';
            roomInput.value = '';
            batchInput.value = '';
            notesInput.value = '';
        }
        
        // Scroll to editor
        selectedInfo.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
}

function getTimeForPeriod(period) {
    const times = [
        '9:00-10:00',
        '10:00-11:00',
        '11:15-12:15',
        '12:15-1:15',
        '2:00-3:00',
        '3:00-4:00',
        '4:15-5:15',
        '5:15-6:15'
    ];
    return times[period - 1] || '';
}

function savePeriod() {
    if (!currentEditingCell) {
        showError('Please select a period to edit first');
        return;
    }
    
    const subjectInput = document.getElementById('subject');
    const classTypeSelect = document.getElementById('classType');
    const roomInput = document.getElementById('room');
    const batchInput = document.getElementById('batch');
    const notesInput = document.getElementById('notes');
    
    const subject = subjectInput.value.trim();
    const classType = classTypeSelect.value;
    const room = roomInput.value.trim();
    const batch = batchInput.value.trim();
    const notes = notesInput.value.trim();
    
    // Update cell
    const cell = currentEditingCell.element;
    cell.className = `period-cell ${classType}`;
    
    // Clear existing content
    cell.innerHTML = '';
    
    // Add period number
    const periodNum = document.createElement('div');
    periodNum.className = 'period-number';
    periodNum.textContent = `P${currentEditingCell.period}`;
    cell.appendChild(periodNum);
    
    // Add subject
    if (subject) {
        const subjectDiv = document.createElement('div');
        subjectDiv.className = 'subject-name';
        subjectDiv.textContent = subject;
        cell.appendChild(subjectDiv);
    }
    
    // Add batch
    if (batch) {
        const batchDiv = document.createElement('div');
        batchDiv.className = 'batch-info';
        batchDiv.textContent = batch;
        cell.appendChild(batchDiv);
    }
    
    // Add room
    if (room) {
        const roomDiv = document.createElement('div');
        roomDiv.className = 'room-number';
        roomDiv.textContent = room;
        cell.appendChild(roomDiv);
    }
    
    // Add notes icon
    if (notes) {
        const notesIcon = document.createElement('div');
        notesIcon.className = 'notes-icon';
        notesIcon.innerHTML = '<i class="fas fa-sticky-note"></i>';
        notesIcon.title = notes;
        cell.appendChild(notesIcon);
    }
    
    // Save to data object
    const key = `${currentEditingCell.day}-${currentEditingCell.period}`;
    timetableData[key] = {
        subject: subject,
        type: classType,
        room: room,
        batch: batch,
        notes: notes,
        timestamp: new Date().toISOString()
    };
    
    updateStats();
    showSuccess('Period saved successfully!');
}

function clearPeriod() {
    if (!currentEditingCell) return;
    
    const cell = currentEditingCell.element;
    cell.className = 'period-cell empty';
    
    // Reset to empty state
    cell.innerHTML = '';
    
    const periodNum = document.createElement('div');
    periodNum.className = 'period-number';
    periodNum.textContent = `P${currentEditingCell.period}`;
    cell.appendChild(periodNum);
    
    const placeholder = document.createElement('div');
    placeholder.className = 'period-placeholder';
    placeholder.textContent = 'Click to edit';
    cell.appendChild(placeholder);
    
    // Remove from data
    const key = `${currentEditingCell.day}-${currentEditingCell.period}`;
    delete timetableData[key];
    
    // Clear form
    const subjectInput = document.getElementById('subject');
    const classTypeSelect = document.getElementById('classType');
    const roomInput = document.getElementById('room');
    const batchInput = document.getElementById('batch');
    const notesInput = document.getElementById('notes');
    
    if (subjectInput) subjectInput.value = '';
    if (classTypeSelect) classTypeSelect.value = 'lecture';
    if (roomInput) roomInput.value = '';
    if (batchInput) batchInput.value = '';
    if (notesInput) notesInput.value = '';
    
    updateStats();
}

async function saveTimetable() {
    if (Object.keys(timetableData).length === 0) {
        showError('Timetable is empty. Please add some periods before saving.');
        return;
    }
    
    try {
        const facultyName = document.getElementById('facultyName')?.value || 'Faculty';
        
        const response = await fetch('/save_timetable', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ 
                timetable: timetableData,
                faculty_name: facultyName
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            showSuccess(data.message);
            
            // Save faculty ID
            if (data.faculty_id) {
                facultyId = data.faculty_id;
                localStorage.setItem('facultyId', facultyId);
                const facultyIdElement = document.getElementById('facultyId');
                if (facultyIdElement) {
                    facultyIdElement.textContent = facultyId;
                }
            }
            
            // Update last saved time
            const now = new Date();
            const lastSaved = now.toLocaleDateString() + ' ' + now.toLocaleTimeString();
            localStorage.setItem('lastSaved', lastSaved);
            const lastSavedElement = document.getElementById('lastSaved');
            if (lastSavedElement) {
                lastSavedElement.textContent = lastSaved;
            }
            
        } else {
            showError('Error saving timetable: ' + data.error);
        }
    } catch (error) {
        showError('Failed to save timetable: ' + error.message);
    }
}

async function loadTimetable() {
    try {
        const response = await fetch('/load_timetable');
        const data = await response.json();
        
        if (data.timetable && Object.keys(data.timetable).length > 0) {
            timetableData = data.timetable;
            updateTimetableUI();
            updateStats();
            
            if (data.faculty_id) {
                facultyId = data.faculty_id;
                localStorage.setItem('facultyId', facultyId);
                const facultyIdElement = document.getElementById('facultyId');
                if (facultyIdElement) {
                    facultyIdElement.textContent = facultyId;
                }
            }
            
            if (data.last_updated) {
                const lastSaved = new Date(data.last_updated).toLocaleString();
                localStorage.setItem('lastSaved', lastSaved);
                const lastSavedElement = document.getElementById('lastSaved');
                if (lastSavedElement) {
                    lastSavedElement.textContent = lastSaved;
                }
            }
            
            showSuccess('Timetable loaded successfully!');
        } else {
            showInfo('No saved timetable found. Create a new one.');
        }
    } catch (error) {
        console.error('Error loading timetable:', error);
        showError('Failed to load timetable');
    }
}

function updateTimetableUI() {
    const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const periods = 8;
    
    days.forEach(day => {
        for (let period = 1; period <= periods; period++) {
            const key = `${day}-${period}`;
            const cell = document.querySelector(`[data-day="${day}"][data-period="${period}"] .period-cell`);
            
            if (cell && timetableData[key]) {
                const periodData = timetableData[key];
                cell.className = `period-cell ${periodData.type}`;
                
                // Clear existing content
                cell.innerHTML = '';
                
                // Add period number
                const periodNum = document.createElement('div');
                periodNum.className = 'period-number';
                periodNum.textContent = `P${period}`;
                cell.appendChild(periodNum);
                
                // Add subject
                if (periodData.subject) {
                    const subjectDiv = document.createElement('div');
                    subjectDiv.className = 'subject-name';
                    subjectDiv.textContent = periodData.subject;
                    cell.appendChild(subjectDiv);
                }
                
                // Add batch
                if (periodData.batch) {
                    const batchDiv = document.createElement('div');
                    batchDiv.className = 'batch-info';
                    batchDiv.textContent = periodData.batch;
                    cell.appendChild(batchDiv);
                }
                
                // Add room
                if (periodData.room) {
                    const roomDiv = document.createElement('div');
                    roomDiv.className = 'room-number';
                    roomDiv.textContent = periodData.room;
                    cell.appendChild(roomDiv);
                }
                
                // Add notes icon
                if (periodData.notes) {
                    const notesIcon = document.createElement('div');
                    notesIcon.className = 'notes-icon';
                    notesIcon.innerHTML = '<i class="fas fa-sticky-note"></i>';
                    notesIcon.title = periodData.notes;
                    cell.appendChild(notesIcon);
                }
            }
        }
    });
}

function clearTimetable() {
    if (!confirm('Are you sure you want to clear the entire timetable? This cannot be undone.')) {
        return;
    }
    
    timetableData = {};
    generateTimetable();
    updateStats();
    
    // Clear form
    const subjectInput = document.getElementById('subject');
    const classTypeSelect = document.getElementById('classType');
    const roomInput = document.getElementById('room');
    const batchInput = document.getElementById('batch');
    const notesInput = document.getElementById('notes');
    const selectedInfo = document.getElementById('selectedPeriodInfo');
    
    if (subjectInput) subjectInput.value = '';
    if (classTypeSelect) classTypeSelect.value = 'lecture';
    if (roomInput) roomInput.value = '';
    if (batchInput) batchInput.value = '';
    if (notesInput) notesInput.value = '';
    if (selectedInfo) {
        selectedInfo.textContent = 'Click on a period to edit';
        selectedInfo.className = 'selected-period';
    }
    
    showSuccess('Timetable cleared!');
}

function updateStats() {
    const total = 48; // 6 days × 8 periods
    const assigned = Object.keys(timetableData).length;
    const free = total - assigned;
    
    const totalPeriodsElement = document.getElementById('totalPeriods');
    const assignedPeriodsElement = document.getElementById('assignedPeriods');
    const freePeriodsElement = document.getElementById('freePeriods');
    
    if (totalPeriodsElement) totalPeriodsElement.textContent = total;
    if (assignedPeriodsElement) assignedPeriodsElement.textContent = assigned;
    if (freePeriodsElement) freePeriodsElement.textContent = free;
    
    // Update progress bar if exists
    const progressBar = document.querySelector('.progress-bar');
    if (progressBar) {
        const percentage = (assigned / total) * 100;
        progressBar.style.width = percentage + '%';
        progressBar.setAttribute('aria-valuenow', percentage);
    }
}

// ==================== TEMPLATES ====================
function applyPattern(patternName) {
    const patterns = {
        'regular': {
            'Monday-1': { subject: 'Mathematics', type: 'lecture', room: 'Room 101', batch: 'CS-A' },
            'Monday-2': { subject: 'Physics', type: 'lecture', room: 'Room 102', batch: 'CS-A' },
            'Monday-3': { subject: 'Chemistry', type: 'lecture', room: 'Room 103', batch: 'CS-A' },
            'Monday-4': { subject: 'Programming Lab', type: 'lab', room: 'Lab 1', batch: 'CS-A' },
            'Tuesday-1': { subject: 'Data Structures', type: 'lecture', room: 'Room 104', batch: 'CS-A' },
            'Tuesday-2': { subject: 'Mathematics Tutorial', type: 'tutorial', room: 'Room 101', batch: 'CS-A' },
            'Wednesday-1': { subject: 'Physics Lab', type: 'lab', room: 'Lab 2', batch: 'CS-A' },
            'Wednesday-2': { subject: 'Physics Lab', type: 'lab', room: 'Lab 2', batch: 'CS-A' },
            'Thursday-1': { subject: 'Workshop', type: 'lab', room: 'Workshop', batch: 'CS-A' },
            'Friday-1': { subject: 'Elective 1', type: 'lecture', room: 'Room 105', batch: 'CS-A' },
            'Friday-2': { subject: 'Elective 2', type: 'lecture', room: 'Room 106', batch: 'CS-A' },
            'Saturday-1': { subject: 'Project Guidance', type: 'project', room: 'Room 107', batch: 'CS-A' }
        },
        'lab': {
            'Monday-1': { subject: 'Chemistry Lab', type: 'lab', room: 'Lab 1', batch: 'CS-A' },
            'Monday-2': { subject: 'Chemistry Lab', type: 'lab', room: 'Lab 1', batch: 'CS-A' },
            'Monday-3': { subject: 'Physics Lab', type: 'lab', room: 'Lab 2', batch: 'CS-A' },
            'Monday-4': { subject: 'Physics Lab', type: 'lab', room: 'Lab 2', batch: 'CS-A' },
            'Tuesday-1': { subject: 'Programming Lab', type: 'lab', room: 'Lab 3', batch: 'CS-A' },
            'Tuesday-2': { subject: 'Programming Lab', type: 'lab', room: 'Lab 3', batch: 'CS-A' },
            'Wednesday-1': { subject: 'Electronics Lab', type: 'lab', room: 'Lab 4', batch: 'CS-A' },
            'Wednesday-2': { subject: 'Electronics Lab', type: 'lab', room: 'Lab 4', batch: 'CS-A' }
        },
        'tutorial': {
            'Monday-1': { subject: 'Math Tutorial', type: 'tutorial', room: 'Room 101', batch: 'CS-A' },
            'Monday-2': { subject: 'Physics Tutorial', type: 'tutorial', room: 'Room 102', batch: 'CS-A' },
            'Tuesday-1': { subject: 'Chemistry Tutorial', type: 'tutorial', room: 'Room 103', batch: 'CS-A' },
            'Wednesday-1': { subject: 'CS Tutorial', type: 'tutorial', room: 'Room 104', batch: 'CS-A' }
        },
        'light': {
            'Monday-1': { subject: 'Mathematics', type: 'lecture', room: 'Room 101', batch: 'CS-A' },
            'Wednesday-1': { subject: 'Physics', type: 'lecture', room: 'Room 102', batch: 'CS-A' },
            'Friday-1': { subject: 'Chemistry', type: 'lecture', room: 'Room 103', batch: 'CS-A' }
        }
    };
    
    const pattern = patterns[patternName];
    if (!pattern) {
        showError('Template not found!');
        return;
    }
    
    // Merge pattern with existing data
    timetableData = { ...timetableData, ...pattern };
    updateTimetableUI();
    updateStats();
    
    showSuccess(`Applied "${patternName}" template!`);
}

// ==================== EXPORT FUNCTIONS ====================
function exportCSV() {
    let csvContent = "Day,Period,Time,Subject,Type,Room,Batch,Notes\n";
    
    const times = [
        '9:00-10:00',
        '10:00-11:00',
        '11:15-12:15',
        '12:15-1:15',
        '2:00-3:00',
        '3:00-4:00',
        '4:15-5:15',
        '5:15-6:15'
    ];
    
    Object.keys(timetableData).forEach(key => {
        const [day, period] = key.split('-');
        const data = timetableData[key];
        const time = times[parseInt(period) - 1] || '';
        
        csvContent += `${day},${period},${time},${data.subject || ''},${data.type || ''},${data.room || ''},${data.batch || ''},"${data.notes || ''}"\n`;
    });
    
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `timetable_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    
    showSuccess('Timetable exported as CSV!');
}

function exportJSON() {
    const dataStr = JSON.stringify(timetableData, null, 2);
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `timetable_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    
    showSuccess('Timetable exported as JSON!');
}

function printTimetable() {
    window.print();
}

function shareTimetable() {
    showInfo('Share feature coming soon! A unique link will be generated for your timetable.');
}

// ==================== UTILITY FUNCTIONS ====================
function showError(message) {
    alert('❌ ' + message);
}

function showSuccess(message) {
    alert('✅ ' + message);
}

function showInfo(message) {
    alert('ℹ️ ' + message);
}

function setupKeyboardShortcuts() {
    document.addEventListener('keydown', function(e) {
        // Ctrl+S to save timetable
        if (e.ctrlKey && e.key === 's') {
            e.preventDefault();
            const saveBtn = document.querySelector('button[onclick="saveTimetable()"]');
            if (saveBtn) saveBtn.click();
        }
        
        // Escape to clear period editor
        if (e.key === 'Escape') {
            const clearBtn = document.querySelector('button[onclick="clearPeriod()"]');
            if (clearBtn) clearBtn.click();
        }
        
        // Ctrl+E to export
        if (e.ctrlKey && e.key === 'e') {
            e.preventDefault();
            exportCSV();
        }
    });
}

async function clearAllData() {
    if (!confirm('Are you sure you want to clear ALL data? This includes calendar and timetable data. This cannot be undone.')) {
        return;
    }
    
    try {
        const response = await fetch('/clear_data', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            }
        });
        
        const data = await response.json();
        
        if (data.success) {
            localStorage.clear();
            timetableData = {};
            
            // Reload page
            window.location.reload();
        } else {
            showError('Failed to clear data');
        }
    } catch (error) {
        showError('Error clearing data: ' + error.message);
    }
}

// ==================== MODAL FUNCTIONS ====================
function copyPeriod() {
    if (!currentEditingCell) {
        showError('Please select a period first');
        return;
    }
    
    document.getElementById('copyModal').style.display = 'flex';
}

function executeCopy() {
    const copySameDay = document.getElementById('copySameDay').checked;
    const copyOtherDays = document.getElementById('copyOtherDays').checked;
    const copyAll = document.getElementById('copyAll').checked;
    
    // Get current period data
    const currentKey = `${currentEditingCell.day}-${currentEditingCell.period}`;
    const currentData = timetableData[currentKey];
    
    if (!currentData) {
        showError('No data to copy!');
        closeModal();
        return;
    }
    
    const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const periods = 8;
    let copiedCount = 0;
    
    if (copyAll) {
        // Copy to all empty periods
        days.forEach(day => {
            for (let period = 1; period <= periods; period++) {
                const key = `${day}-${period}`;
                if (!timetableData[key] && !(day === currentEditingCell.day && period === currentEditingCell.period)) {
                    timetableData[key] = { ...currentData };
                    copiedCount++;
                }
            }
        });
    } else {
        if (copySameDay) {
            // Copy to other periods on same day
            for (let period = 1; period <= periods; period++) {
                if (period !== currentEditingCell.period) {
                    const key = `${currentEditingCell.day}-${period}`;
                    if (!timetableData[key]) {
                        timetableData[key] = { ...currentData };
                        copiedCount++;
                    }
                }
            }
        }
        
        if (copyOtherDays) {
            // Copy to same period on other days
            days.forEach(day => {
                if (day !== currentEditingCell.day) {
                    const key = `${day}-${currentEditingCell.period}`;
                    if (!timetableData[key]) {
                        timetableData[key] = { ...currentData };
                        copiedCount++;
                    }
                }
            });
        }
    }
    
    updateTimetableUI();
    updateStats();
    closeModal();
    
    showSuccess(`Copied to ${copiedCount} periods!`);
}

function closeModal() {
    document.getElementById('copyModal').style.display = 'none';
}

// Close modal when clicking outside
window.onclick = function(event) {
    const modal = document.getElementById('copyModal');
    if (event.target == modal) {
        closeModal();
    }
};

// Apply template from dropdown
function applyTemplate(value) {
    if (value) {
        applyPattern(value);
        const selectElement = document.getElementById('scheduleTemplate');
        if (selectElement) {
            selectElement.value = '';
        }
    }
}