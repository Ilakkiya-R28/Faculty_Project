from flask import Flask, render_template, request, jsonify, redirect, url_for, flash, send_from_directory
import json
import os
import pandas as pd
import re
from datetime import datetime
from werkzeug.utils import secure_filename
from openpyxl import load_workbook
from pptx import Presentation
import tempfile

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key-here'
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['TIMETABLE_FOLDER'] = 'timetable_uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024

# Year configurations
YEAR_FOLDERS = {
    'first': 'first_year',
    'second': 'second_year',
    'third': 'third_year',
    'fourth': 'fourth_year'
}

ALLOWED_EXTENSIONS = {'xlsx', 'xls', 'csv'}
ALLOWED_TIMETABLE_EXTENSIONS = {'pptx', 'ppt'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def allowed_timetable_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_TIMETABLE_EXTENSIONS

def ensure_year_folders():
    """Create year folders if they don't exist"""
    for year in YEAR_FOLDERS.values():
        folder_path = os.path.join(app.config['UPLOAD_FOLDER'], year)
        os.makedirs(folder_path, exist_ok=True)
    
    # Create timetable folder
    os.makedirs(app.config['TIMETABLE_FOLDER'], exist_ok=True)

def parse_calendar(filepath, year_type):
    """Parse the calendar Excel file and separate into working days, holidays, and exam days"""
    try:
        print(f"=== Parsing calendar file: {filepath} ===")
        
        # Try to read the Excel file
        try:
            # First, list all sheets
            xl = pd.read_excel(filepath, sheet_name=None)
            print(f"Available sheets: {xl.sheet_names}")
            
            # Try to find Sheet3
            target_sheet = None
            for sheet_name in xl.sheet_names:
                if 'Sheet3' in sheet_name or sheet_name == 'Sheet3':
                    target_sheet = sheet_name
                    break
            
            if target_sheet:
                print(f"Using sheet: {target_sheet}")
                df = pd.read_excel(filepath, sheet_name=target_sheet, header=None)
            else:
                # If no Sheet3, try sheet index 1 (0-based)
                if len(xl.sheet_names) > 1:
                    df = pd.read_excel(filepath, sheet_name=1, header=None)
                    print(f"Using sheet index 1: {xl.sheet_names[1]}")
                else:
                    df = pd.read_excel(filepath, sheet_name=0, header=None)
                    print(f"Using first sheet: {xl.sheet_names[0]}")
                    
        except Exception as e:
            print(f"Error reading Excel with engine detection: {e}")
            # Fallback to simple read
            df = pd.read_excel(filepath, sheet_name=0, header=None)
        
        print(f"DataFrame shape: {df.shape}")
        
        working_days = []
        holidays = []
        exam_days = []
        other_event_days = []
        current_month = None
        current_year = None
        academic_year = None
        
        # Month mapping
        months = {
            'JANUARY': 1, 'FEBRUARY': 2, 'MARCH': 3, 'APRIL': 4, 'MAY': 5, 'JUNE': 6,
            'JULY': 7, 'AUGUST': 8, 'SEPTEMBER': 9, 'OCTOBER': 10, 'NOVEMBER': 11, 'DECEMBER': 12
        }
        
        # Process each row
        for index, row in df.iterrows():
            try:
                # Get cell values (handle missing columns)
                col_a = row[0] if len(row) > 0 else None
                col_b = row[1] if len(row) > 1 else None
                col_c = row[2] if len(row) > 2 else None
                col_d = row[3] if len(row) > 3 else None
                
                # Convert to strings for text processing
                str_a = str(col_a) if not pd.isna(col_a) else ""
                str_b = str(col_b) if not pd.isna(col_b) else ""
                str_c = str(col_c) if not pd.isna(col_c) else ""
                str_d = str(col_d) if not pd.isna(col_d) else ""
                
                # Check for academic year
                if 'Academic Year' in str_a and not academic_year:
                    match = re.search(r'(\d{4})\s*[-]\s*(\d{2})', str_a)
                    if match:
                        academic_year = f"{match.group(1)}-{match.group(2)}"
                        print(f"Found academic year: {academic_year}")
                
                # Check for month header
                month_found = False
                for month_name in months.keys():
                    if month_name in str_a.upper():
                        current_month = month_name
                        # Extract year from month header
                        year_match = re.search(r'\b(20\d{2})\b', str_a.upper())
                        if year_match:
                            current_year = int(year_match.group(1))
                        elif not current_year:
                            current_year = 2025  # Default
                        print(f"Found month: {current_month} {current_year}")
                        month_found = True
                        break
                
                # Skip if we don't have a month yet
                if not current_month:
                    continue
                
                # Check if this is a date row (numeric date in column A)
                if pd.notna(col_a) and isinstance(col_a, (int, float)):
                    try:
                        date_num = int(float(col_a))
                        if 1 <= date_num <= 31:
                            # Create date string
                            date_str = f"{date_num} {current_month} {current_year}"
                            
                            # Get day name
                            day_name = str_b.strip() if str_b.strip() else ""
                            
                            # Check for working day count
                            working_count = None
                            is_working = False
                            
                            if pd.notna(col_c):
                                try:
                                    if isinstance(col_c, (int, float)):
                                        working_count = int(col_c)
                                        is_working = True
                                    elif isinstance(col_c, str) and col_c.strip().isdigit():
                                        working_count = int(col_c.strip())
                                        is_working = True
                                except (ValueError, TypeError):
                                    pass
                            
                            # Get event
                            event = str_d.strip() if str_d.strip() and str_d.strip().lower() != 'nan' else ""
                            
                            # Check event type
                            event_lower = event.lower() if event else ""
                            
                            # Check if it's a holiday
                            is_holiday = False
                            holiday_terms = ['holiday', 'break', 'festival', 'celebration', 'national']
                            if event:
                                is_holiday = any(term in event_lower for term in holiday_terms)
                            
                            # Check if it's an exam day
                            is_exam = False
                            exam_terms = ['exam', 'examination', 'final', 'mid-term', 'midterm', 'test', 'assessment']
                            if event:
                                is_exam = any(term in event_lower for term in exam_terms)
                            
                            # Create day data structure
                            day_data = {
                                'date': date_str,
                                'day': day_name,
                                'event': event,
                                'date_number': date_num,
                                'month': current_month,
                                'year': current_year,
                                'month_num': months[current_month],
                                'is_working_day': is_working,
                                'working_day_number': working_count if is_working else None
                            }
                            
                            # Categorize the day
                            if is_working and working_count is not None and not is_holiday:
                                # It's a working day (not a holiday)
                                working_days.append(day_data)
                            
                            if is_holiday:
                                # It's a holiday
                                holidays.append(day_data)
                            
                            if is_exam:
                                # It's an exam day
                                exam_days.append(day_data)
                            
                            if event and not is_holiday and not is_exam:
                                # It's another type of event
                                other_event_days.append(day_data)
                                
                    except Exception as e:
                        print(f"Error processing date row {index}: {e}")
                        continue
                        
            except Exception as e:
                print(f"Error processing row {index}: {e}")
                continue
        
        print(f"Parsing complete:")
        print(f"  Working days: {len(working_days)}")
        print(f"  Holidays: {len(holidays)}")
        print(f"  Exam days: {len(exam_days)}")
        print(f"  Other events: {len(other_event_days)}")
        
        # Sort by date
        def sort_by_date(days_list):
            return sorted(days_list, key=lambda x: (x['year'], x['month_num'], x['date_number']))
        
        working_days = sort_by_date(working_days)
        holidays = sort_by_date(holidays)
        exam_days = sort_by_date(exam_days)
        other_event_days = sort_by_date(other_event_days)
        
        # Calculate totals
        total_working_days = len(working_days)
        total_holidays = len(holidays)
        total_exam_days = len(exam_days)
        total_other_events = len(other_event_days)
        
        # Set academic year if not found
        if not academic_year and current_year:
            academic_year = f"{current_year}-{current_year + 1}"
        
        return {
            'working_days': working_days,
            'holidays': holidays,
            'exam_days': exam_days,
            'other_event_days': other_event_days,
            'total_working_days': total_working_days,
            'total_holidays': total_holidays,
            'total_exam_days': total_exam_days,
            'total_other_events': total_other_events,
            'academic_year': academic_year if academic_year else "N/A"
        }
    
    except Exception as e:
        print(f"Error in parse_calendar: {str(e)}")
        import traceback
        traceback.print_exc()
        return None

def parse_timetable_pptx(filepath):
    """Parse PowerPoint timetable file"""
    try:
        print(f"=== Parsing timetable file: {filepath} ===")
        
        # Load presentation
        presentation = Presentation(filepath)
        
        timetable_data = {
            'id': None,
            'faculty_name': None,
            'department': None,
            'subjects': [],
            'periods': [],
            'raw_text': "",
            'slide_count': len(presentation.slides)
        }
        
        # Extract text from all slides
        all_text = []
        for slide_num, slide in enumerate(presentation.slides):
            for shape in slide.shapes:
                if hasattr(shape, "text"):
                    text = shape.text.strip()
                    if text:
                        all_text.append(text)
        
        # Join all text
        full_text = "\n".join(all_text)
        timetable_data['raw_text'] = full_text
        
        print(f"Extracted text from PPTX:\n{full_text}")
        
        # Parse basic information using regex patterns
        patterns = {
            'id': [r'Timetable\s*[Ii]d\s*[:\s]*([A-Za-z0-9]+)', r'ID\s*[:\s]*([A-Za-z0-9]+)'],
            'faculty_name': [r'Faculty\s*Name\s*[:\s]*([A-Za-z\s\.]+)', r'Name\s*[:\s]*([A-Za-z\s\.]+)'],
            'department': [r'Department\s*[:\s]*([A-Za-z0-9\s]+)']
        }
        
        # Extract ID
        for pattern in patterns['id']:
            match = re.search(pattern, full_text, re.IGNORECASE)
            if match:
                timetable_data['id'] = match.group(1).strip()
                break
        
        # Extract Faculty Name
        for pattern in patterns['faculty_name']:
            match = re.search(pattern, full_text, re.IGNORECASE)
            if match:
                timetable_data['faculty_name'] = match.group(1).strip()
                break
        
        # Extract Department
        for pattern in patterns['department']:
            match = re.search(pattern, full_text, re.IGNORECASE)
            if match:
                timetable_data['department'] = match.group(1).strip()
                break
        
        # Extract subjects (looking for course codes like CS101, MAT202, etc.)
        subject_patterns = [
            r'([A-Z]{2,4}\s*\d{3,4})',  # Like CS101, MAT202
            r'([A-Z]{2,4}-\d{3,4})',    # Like CS-101
            r'Subject\s*[:\s]*([A-Za-z0-9\s]+)',
            r'Course\s*[:\s]*([A-Za-z0-9\s]+)'
        ]
        
        subjects_set = set()
        for pattern in subject_patterns:
            matches = re.findall(pattern, full_text, re.IGNORECASE)
            for match in matches:
                if isinstance(match, tuple):
                    for item in match:
                        if item.strip():
                            subjects_set.add(item.strip())
                else:
                    if match.strip():
                        subjects_set.add(match.strip())
        
        timetable_data['subjects'] = list(subjects_set)
        
        # Extract periods (looking for period information)
        period_patterns = [
            r'Period\s*(\d+)',
            r'P\s*(\d+)',
            r'(\d+)\s*(?:st|nd|rd|th)\s*Period',
            r'(\d+)\s*-\s*(\d+)\s*(?:hours?|hrs?)'  # Time slots like 9-10 hours
        ]
        
        periods_set = set()
        for pattern in period_patterns:
            matches = re.findall(pattern, full_text, re.IGNORECASE)
            for match in matches:
                if isinstance(match, tuple):
                    for item in match:
                        if item.strip():
                            periods_set.add(f"Period {item.strip()}")
                else:
                    if match.strip():
                        periods_set.add(f"Period {match.strip()}")
        
        timetable_data['periods'] = list(periods_set)
        
        print(f"Parsed timetable data: {timetable_data}")
        return timetable_data
        
    except Exception as e:
        print(f"Error parsing timetable PPTX: {str(e)}")
        import traceback
        traceback.print_exc()
        return None

def get_uploaded_calendars():
    """Get list of all uploaded calendars"""
    calendars = {}
    for year_key, folder_name in YEAR_FOLDERS.items():
        folder_path = os.path.join(app.config['UPLOAD_FOLDER'], folder_name)
        if os.path.exists(folder_path):
            files = os.listdir(folder_path)
            if files:
                # Get the latest file
                latest_file = max(files, key=lambda x: os.path.getctime(os.path.join(folder_path, x)))
                calendars[year_key] = {
                    'filename': latest_file,
                    'uploaded_at': datetime.fromtimestamp(
                        os.path.getctime(os.path.join(folder_path, latest_file))
                    ).strftime('%Y-%m-%d %H:%M:%S')
                }
    return calendars

def get_uploaded_timetables():
    """Get list of all uploaded timetables"""
    timetable_data = []
    folder_path = app.config['TIMETABLE_FOLDER']
    
    if os.path.exists(folder_path):
        for filename in os.listdir(folder_path):
            if filename.lower().endswith(('.pptx', '.ppt')):
                filepath = os.path.join(folder_path, filename)
                parsed_data = parse_timetable_pptx(filepath)
                if parsed_data:
                    parsed_data['filename'] = filename
                    parsed_data['uploaded_at'] = datetime.fromtimestamp(
                        os.path.getctime(filepath)
                    ).strftime('%Y-%m-%d %H:%M:%S')
                    parsed_data['file_size'] = os.path.getsize(filepath)
                    timetable_data.append(parsed_data)
    
    return timetable_data

@app.route('/')
def index():
    calendars = get_uploaded_calendars()
    return render_template('index.html', uploaded_calendars=calendars)

@app.route('/year/<year_type>')
def year_view(year_type):
    if year_type not in YEAR_FOLDERS:
        return redirect(url_for('index'))
    
    folder_path = os.path.join(app.config['UPLOAD_FOLDER'], YEAR_FOLDERS[year_type])
    calendar_data = None
    filename = None
    
    if os.path.exists(folder_path):
        files = os.listdir(folder_path)
        if files:
            filename = max(files, key=lambda x: os.path.getctime(os.path.join(folder_path, x)))
            filepath = os.path.join(folder_path, filename)
            calendar_data = parse_calendar(filepath, year_type)
    
    return render_template('year_view.html', 
                         year_type=year_type,
                         year_name=f"{year_type.capitalize()} Year",
                         calendar_data=calendar_data,
                         filename=filename)

@app.route('/timetables')
def timetables_view():
    timetable_data = get_uploaded_timetables()
    
    # Get unique departments, subjects, and periods for filters
    departments = set()
    subjects = set()
    periods = set()
    
    for timetable in timetable_data:
        if timetable.get('department'):
            departments.add(timetable['department'])
        if timetable.get('subjects'):
            subjects.update(timetable['subjects'])
        if timetable.get('periods'):
            periods.update(timetable['periods'])
    
    # Get filter parameters
    dept_filter = request.args.get('department', '')
    subject_filter = request.args.get('subject', '')
    period_filter = request.args.get('period', '')
    show_filled_only = request.args.get('filled_only', 'false') == 'true'
    
    # Apply filters
    filtered_timetables = []
    for timetable in timetable_data:
        # Skip empty timetables if show_filled_only is True
        if show_filled_only and (not timetable.get('subjects') or len(timetable['subjects']) == 0):
            continue
        
        # Apply department filter
        if dept_filter and timetable.get('department') != dept_filter:
            continue
        
        # Apply subject filter
        if subject_filter:
            if not timetable.get('subjects') or subject_filter not in timetable['subjects']:
                continue
        
        # Apply period filter
        if period_filter:
            if not timetable.get('periods') or period_filter not in timetable['periods']:
                continue
        
        filtered_timetables.append(timetable)
    
    return render_template('timetables.html',
                         timetables=filtered_timetables,
                         departments=sorted(departments),
                         subjects=sorted(subjects),
                         periods=sorted(periods),
                         dept_filter=dept_filter,
                         subject_filter=subject_filter,
                         period_filter=period_filter,
                         show_filled_only=show_filled_only)

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({'success': False, 'message': 'No file part'})
    
    file = request.files['file']
    year_type = request.form.get('year_type', 'first')
    
    if year_type not in YEAR_FOLDERS:
        return jsonify({'success': False, 'message': 'Invalid year type'})
    
    if file.filename == '':
        return jsonify({'success': False, 'message': 'No selected file'})
    
    if file and allowed_file(file.filename):
        try:
            # Ensure folders exist
            ensure_year_folders()
            
            # Save file
            original_filename = secure_filename(file.filename)
            filename = f"{datetime.now().strftime('%Y%m%d_%H%M%S')}_{original_filename}"
            folder_name = YEAR_FOLDERS[year_type]
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], folder_name, filename)
            file.save(filepath)
            
            print(f"File saved to: {filepath}")
            print(f"File size: {os.path.getsize(filepath)} bytes")
            
            # Parse the calendar
            calendar_data = parse_calendar(filepath, year_type)
            
            if calendar_data:
                return jsonify({
                    'success': True,
                    'message': f'Calendar uploaded successfully! Found {calendar_data["total_working_days"]} working days, {calendar_data["total_holidays"]} holidays, and {calendar_data["total_exam_days"]} exam days.',
                    'year_type': year_type,
                    'filename': filename,
                    'data': calendar_data
                })
            else:
                # Remove file if parsing failed
                if os.path.exists(filepath):
                    os.remove(filepath)
                return jsonify({
                    'success': False, 
                    'message': 'Failed to parse calendar. Please ensure you are uploading the correct Excel file format.'
                })
        
        except Exception as e:
            error_msg = str(e)
            print(f"Upload error: {error_msg}")
            import traceback
            traceback.print_exc()
            
            if 'filepath' in locals() and os.path.exists(filepath):
                os.remove(filepath)
            return jsonify({'success': False, 'message': f'Error: {error_msg}'})
    
    return jsonify({'success': False, 'message': 'Invalid file type. Please upload Excel (.xlsx, .xls) files.'})

@app.route('/upload_timetable', methods=['POST'])
def upload_timetable():
    if 'file' not in request.files:
        return jsonify({'success': False, 'message': 'No file part'})
    
    file = request.files['file']
    
    if file.filename == '':
        return jsonify({'success': False, 'message': 'No selected file'})
    
    if file and allowed_timetable_file(file.filename):
        try:
            # Ensure folders exist
            ensure_year_folders()
            
            # Save file
            original_filename = secure_filename(file.filename)
            filename = f"{datetime.now().strftime('%Y%m%d_%H%M%S')}_{original_filename}"
            filepath = os.path.join(app.config['TIMETABLE_FOLDER'], filename)
            file.save(filepath)
            
            print(f"Timetable file saved to: {filepath}")
            print(f"File size: {os.path.getsize(filepath)} bytes")
            
            # Parse the timetable
            timetable_data = parse_timetable_pptx(filepath)
            
            if timetable_data:
                return jsonify({
                    'success': True,
                    'message': f'Timetable uploaded successfully! Extracted data for {timetable_data.get("faculty_name", "Unknown")}.',
                    'filename': filename,
                    'data': timetable_data
                })
            else:
                # Remove file if parsing failed
                if os.path.exists(filepath):
                    os.remove(filepath)
                return jsonify({
                    'success': False, 
                    'message': 'Failed to parse timetable. Please ensure you are uploading a valid PowerPoint file.'
                })
        
        except Exception as e:
            error_msg = str(e)
            print(f"Timetable upload error: {error_msg}")
            import traceback
            traceback.print_exc()
            
            if 'filepath' in locals() and os.path.exists(filepath):
                os.remove(filepath)
            return jsonify({'success': False, 'message': f'Error: {error_msg}'})
    
    return jsonify({'success': False, 'message': 'Invalid file type. Please upload PowerPoint (.pptx, .ppt) files.'})

@app.route('/delete_calendar/<year_type>', methods=['DELETE'])
def delete_calendar(year_type):
    if year_type not in YEAR_FOLDERS:
        return jsonify({'success': False, 'message': 'Invalid year type'})
    
    folder_path = os.path.join(app.config['UPLOAD_FOLDER'], YEAR_FOLDERS[year_type])
    
    if os.path.exists(folder_path):
        for filename in os.listdir(folder_path):
            file_path = os.path.join(folder_path, filename)
            os.remove(file_path)
    
    return jsonify({'success': True, 'message': f'Calendar deleted for {year_type.capitalize()} Year'})

@app.route('/delete_timetable/<filename>', methods=['DELETE'])
def delete_timetable(filename):
    try:
        filepath = os.path.join(app.config['TIMETABLE_FOLDER'], secure_filename(filename))
        
        if os.path.exists(filepath):
            os.remove(filepath)
            return jsonify({'success': True, 'message': f'Timetable {filename} deleted successfully.'})
        else:
            return jsonify({'success': False, 'message': 'File not found.'})
    
    except Exception as e:
        return jsonify({'success': False, 'message': f'Error: {str(e)}'})

@app.route('/download_calendar/<year_type>')
def download_calendar(year_type):
    if year_type not in YEAR_FOLDERS:
        return redirect(url_for('index'))
    
    folder_path = os.path.join(app.config['UPLOAD_FOLDER'], YEAR_FOLDERS[year_type])
    
    if os.path.exists(folder_path):
        files = os.listdir(folder_path)
        if files:
            filename = max(files, key=lambda x: os.path.getctime(os.path.join(folder_path, x)))
            return send_from_directory(folder_path, filename, as_attachment=True)
    
    flash('No calendar found for download')
    return redirect(url_for('year_view', year_type=year_type))

@app.route('/download_timetable/<filename>')
def download_timetable(filename):
    folder_path = app.config['TIMETABLE_FOLDER']
    filepath = os.path.join(folder_path, secure_filename(filename))
    
    if os.path.exists(filepath):
        return send_from_directory(folder_path, filename, as_attachment=True)
    
    flash('Timetable file not found')
    return redirect(url_for('timetables_view'))

@app.route('/api/calendar_status')
def calendar_status():
    calendars = get_uploaded_calendars()
    return jsonify(calendars)

@app.route('/api/timetable_status')
def timetable_status():
    timetables = get_uploaded_timetables()
    return jsonify(timetables)

if __name__ == '__main__':
    ensure_year_folders()
    app.run(debug=True, port=5000)